﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.Runtime.InteropServices;
using System.Text;

public class changeImage : MonoBehaviour {

    public GameObject face;

    public void changecolor(Texture2D thisColor)
    {
        face.GetComponent<Renderer>().material.mainTexture = thisColor;
    }

}